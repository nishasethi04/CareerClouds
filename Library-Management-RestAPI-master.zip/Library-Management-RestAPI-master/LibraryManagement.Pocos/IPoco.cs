﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryManagement.Pocos
{
    public interface IPoco
    {
        public Guid Id { get; set; }
    }
}
